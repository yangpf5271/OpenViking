# What changed before publishing

This archive is a snapshot of a local sandbox, so it was scrubbed before it was
committed. Every substitution below was applied to every file, and the result
was re-scanned for each original string (zero hits remain).

| original | published as | where it appeared |
| --- | --- | --- |
| OpenViking API key | not present | only ever lived in `env.sh`, which is not in this archive |
| Volcengine Ark API key | not present | only ever lived in `env.sh`, which is not in this archive |
| the operator's local username | `demo-user` | `ls -la` output the agent captured, so it reached the payloads, the session file and the OpenViking archive |
| a private proxy in front of Volcengine Ark | `https://ark.cn-beijing.volces.com/api/v3`, the official endpoint it forwards to | `agent/models.json`, `run.sh`, both `INDEX.md` |

The model was Volcengine's Doubao 2.1 Pro (`doubao-seed-2-1-pro-260628`) with
`reasoning_effort: high` throughout, and the same key reaches it through the
official endpoint written above.

Also removed rather than substituted:

- `env.sh` — the only file that held secrets. `env.sh.example` shows its shape.
- `ext/` — a generated copy of the extension sources, identical to the parent
  directory of this archive.
- `sessions/` and `out/` at the sandbox root — scratch from interactive runs,
  superseded by `demo/` and `demo-long/`.

Deliberately kept, because none of it is a credential:

- pi session ids, OpenViking session ids, archive ids, task ids and trace ids
- `viking://user/default/sessions/...` URIs
- `127.0.0.1` addresses (defaults quoted inside the archived source code)
- the full conversation content, including the extension's own source code,
  which the agent read as part of the task

Verified with: both key values and the proxy hostname each return zero matches
across the archive.
