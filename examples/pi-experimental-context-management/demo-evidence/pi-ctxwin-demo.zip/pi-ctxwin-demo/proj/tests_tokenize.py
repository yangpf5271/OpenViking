#!/usr/bin/env python3
from src.tokenize import tokenize, _read_escape, LexerError


def test_valid_unicode_escape():
    # Test valid unicode escape like \u00e9 (é)
    assert tokenize(r"caf\u00e9") == ["café"], "Valid unicode escape failed"
    # Also test _read_escape directly
    s = r"\u00e9"
    res, pos = _read_escape(s, 0)
    assert res == "é", f"Expected 'é', got {res!r}"
    assert pos == 6, f"Expected pos 6, got {pos}"
    print("✓ test_valid_unicode_escape passed")


def test_truncated_unicode_escape():
    # Test truncated escape at end of string
    try:
        tokenize(r"caf\u")
        assert False, "Expected LexerError for truncated \\u"
    except LexerError as e:
        assert "Incomplete Unicode escape sequence" in str(e), f"Unexpected error: {e}"
    
    # Test escape with only 2 hex digits instead of 4
    try:
        tokenize(r"caf\u00")
        assert False, "Expected LexerError for short \\u"
    except LexerError as e:
        assert "Incomplete Unicode escape sequence" in str(e), f"Unexpected error: {e}"
    
    # Test escape with invalid hex digits
    try:
        tokenize(r"caf\u00g9")
        assert False, "Expected LexerError for invalid hex"
    except LexerError as e:
        assert "Invalid hex digits in Unicode escape sequence" in str(e), f"Unexpected error: {e}"
    
    print("✓ test_truncated_unicode_escape passed")


def test_valid_escapes():
    # Test other valid escape sequences
    assert tokenize(r"hello\\world") == [r"hello\world"], "Backslash escape failed"
    assert tokenize(r"hello\"world") == ['hello"world'], "Quote escape failed"
    assert tokenize(r"hello\nworld") == ["hello\nworld"], "Newline escape failed"
    assert tokenize(r"hello\tworld") == ["hello\tworld"], "Tab escape failed"
    print("✓ test_valid_escapes passed")


def test_unknown_escape():
    try:
        tokenize(r"hello\xworld")
        assert False, "Expected LexerError for unknown escape"
    except LexerError as e:
        assert "Unknown escape sequence" in str(e), f"Unexpected error: {e}"
    print("✓ test_unknown_escape passed")


def test_unterminated_escape():
    try:
        tokenize(r"hello\\")
        # Wait, r"hello\\" ends with a single backslash - let's test that
        # Actually, let's test with a single backslash at end: r"hello\"
        tokenize(r"hello\\")  # This should be okay because it's two backslashes
        # Now test a single backslash at end:
        try:
            # Need to build the string without raw prefix because raw can't end with backslash
            tokenize("hello\\")  # This is a single backslash at end
            assert False, "Expected LexerError for unterminated escape"
        except LexerError as e:
            assert "Unterminated escape sequence" in str(e), f"Unexpected error: {e}"
    except Exception as e:
        assert False, f"Unexpected exception: {type(e).__name__}: {e}"
    print("✓ test_unterminated_escape passed")


if __name__ == "__main__":
    print("Running tests for tokenize.py...\n")
    test_valid_unicode_escape()
    test_truncated_unicode_escape()
    test_valid_escapes()
    test_unknown_escape()
    test_unterminated_escape()
    print("\nAll tests passed! 🎉")
