"""Report rendering for the demo project (phase two material)."""

import csv
import io
from dataclasses import dataclass


@dataclass
class Row:
    name: str
    p50_ms: float
    p99_ms: float


def render(rows: list[Row]) -> str:
    lines = ["| case | p50 | p99 |", "| --- | --- | --- |"]
    for row in rows:
        lines.append(f"| {row.name} | {row.p50_ms:.1f} | {row.p99_ms:.1f} |")
    return "\n".join(lines)


def render_csv(rows: list[Row]) -> str:
    """Render the same rows as CSV."""
    output = io.StringIO()
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(["case", "p50", "p99"])
    for row in rows:
        writer.writerow([row.name, f"{row.p50_ms:.1f}", f"{row.p99_ms:.1f}"])
    return output.getvalue()
