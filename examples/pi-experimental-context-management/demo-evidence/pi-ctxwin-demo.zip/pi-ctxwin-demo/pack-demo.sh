#!/usr/bin/env bash
# Package one e2e workspace into a demo folder.
#
#   ./.tmp/pi-ctxwin/pack-demo.sh <workspace-dir> <out-dir>
#
# Pulls the pi session file, the extension debug log, every provider payload
# summary, the agent's own context-tool calls, the work it produced, and the
# OpenViking archive (Working Memory + raw messages + a grep hit).
set -euo pipefail
W="${1:?usage: pack-demo.sh <workspace> <outdir>}"
OUT="${2:?usage: pack-demo.sh <workspace> <outdir>}"
D="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$D/env.sh"

rm -rf "$OUT"; mkdir -p "$OUT"/{session,payloads,work,archive}
cp "$W"/sessions/*.jsonl "$OUT/session/"
cp "$W"/out/ov-pi.log "$OUT/"
cp "$W"/out/session-id.txt "$OUT/"
for f in "$W"/proj/INVENTORY.md "$W"/proj/TASK.md "$W"/proj/release.md; do
  [ -f "$f" ] && cp "$f" "$OUT/work/"
done

python3 - "$OUT" "$W" <<'PY'
import json, os, re, sys, glob
out, w = sys.argv[1], sys.argv[2]
WINDOW = 128000
rows = []
for f in sorted(glob.glob(os.path.join(w, "out", "payload-t*.json"))):
    p = json.load(open(f)); ms = p.get("messages", [])
    b = sum(len(json.dumps(m)) for m in ms)
    first = next((m for m in ms if m.get("role") not in ("system", "developer")), None)
    t = (first or {}).get("content", "")
    t = t if isinstance(t, str) else "".join(x.get("text", "") for x in t if isinstance(x, dict))
    fresh = t.startswith('<openviking-context source="context-window">')
    m = re.search(r'<context_window id="(w\d+)"', t) if fresh else None
    rows.append({"file": os.path.basename(f), "msgs": len(ms), "bytes": b,
                 "pct": round(b / 4 / WINDOW * 100),
                 "fresh": fresh, "window": m.group(1) if m else "w1"})
# a text chart of the pressure curve, with every reset marked
with open(os.path.join(out, "pressure-timeline.txt"), "w") as fh:
    fh.write("context pressure across the run: one line per provider request\n")
    fh.write("(bytes/4 against the 128k window pi was told about)\n\n")
    for i, r in enumerate(rows):
        previous = rows[i - 1]["window"] if i > 0 else "w1"
        if r["window"] != previous:
            fh.write(f'{"":26s}     ---- new_context: {previous} archived, {r["window"]} opens ----\n')
        bar = "#" * max(1, round(r["pct"] / 2))
        fh.write(f'{r["window"]:3s} {r["file"]:22s} {r["msgs"]:4d} msgs {r["pct"]:3d}% {bar}\n')
    peak = max(rows, key=lambda r: r["bytes"]) if rows else None
    if peak:
        fh.write(f'\npeak: {peak["file"]} {peak["bytes"]} bytes '
                 f'(~{round(peak["bytes"]/4/1000,1)}k tokens, {peak["pct"]}% of 128k)\n')
# keep only the payloads worth opening: peak, the resets and their neighbours
# only the transitions: the request before a reset, the first one after it, and
# the one after that. Every later request also carries the header, and keeping
# all of them buries the interesting three.
keep = set()
for i, r in enumerate(rows):
    previous = rows[i - 1]["window"] if i > 0 else "w1"
    if r["window"] != previous:
        keep.update(rows[j]["file"] for j in (i - 1, i, i + 1) if 0 <= j < len(rows))
if rows:
    keep.add(rows[0]["file"]); keep.add(max(rows, key=lambda r: r["bytes"])["file"])
    keep.add(rows[-1]["file"])
for name in sorted(keep):
    src = os.path.join(w, "out", name)
    if os.path.exists(src):
        open(os.path.join(out, "payloads", name), "wb").write(open(src, "rb").read())
# the header the model actually got, and the tool calls it made on its own
fresh = [r for r in rows if r["fresh"]]
if fresh:
    p = json.load(open(os.path.join(w, "out", fresh[-1]["file"])))
    msg = next(m for m in p["messages"] if m.get("role") not in ("system", "developer"))
    c = msg.get("content")
    open(os.path.join(out, "window-header.txt"), "w").write(
        c if isinstance(c, str) else json.dumps(c, ensure_ascii=False, indent=2))
calls = []
sf = sorted(glob.glob(os.path.join(out, "session", "*.jsonl")))[0]
for line in open(sf):
    r = json.loads(line); m = r.get("message") or {}
    for b in (m.get("content") or []) if isinstance(m.get("content"), list) else []:
        if isinstance(b, dict) and b.get("type") == "toolCall" and b.get("name") in (
                "new_context", "history", "get_context_remaining"):
            calls.append({"tool": b["name"], "arguments": b.get("arguments")})
json.dump(calls, open(os.path.join(out, "context-tool-calls.json"), "w"), ensure_ascii=False, indent=2)
windows = sorted({r["window"] for r in rows}, key=lambda x: int(x[1:]))
print(f'payloads={len(rows)} kept={len(keep)} windows={windows} '
      f'peak={max((r["pct"] for r in rows), default=0)}% tools={[c["tool"] for c in calls]}')
PY

SID="pi-$(cat "$OUT/session-id.txt")"
ROOT="viking://user/default/sessions/$SID"
enc() { python3 -c "import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1],safe=''))" "$1"; }
get() { curl -sS -m 30 -H "Authorization: Bearer $OPENVIKING_API_KEY" "$OPENVIKING_URL$1"; }
body() { python3 -c "import sys,json;d=json.load(sys.stdin);print(d.get('result') if isinstance(d.get('result'),str) else json.dumps(d,ensure_ascii=False,indent=2))"; }
get "/api/v1/fs/ls?uri=$(enc "$ROOT/history")&sort_by=name&sort_order=desc" | python3 -m json.tool > "$OUT/archive/ls-history.json"
for A in $(python3 -c "
import json;d=json.load(open('$OUT/archive/ls-history.json'))
print(' '.join(sorted(e['uri'].rsplit('/',1)[-1] for e in d.get('result',[]))))"); do
  get "/api/v1/content/read?uri=$(enc "$ROOT/history/$A/.overview.md")" | body > "$OUT/archive/$A.overview.md" || true
  get "/api/v1/content/read?uri=$(enc "$ROOT/history/$A/messages.jsonl")" | body > "$OUT/archive/$A.messages.jsonl" || true
done
curl -sS -m 30 -X POST -H "Authorization: Bearer $OPENVIKING_API_KEY" -H "Content-Type: application/json" \
  -d "{\"uri\":\"$ROOT/history\",\"pattern\":\"_read_escape|computeCutRange\",\"case_insensitive\":true}" \
  "$OPENVIKING_URL/api/v1/search/grep" | python3 -m json.tool > "$OUT/archive/grep-sample.json" || true

echo "OV session: $SID"
echo "packed into: $OUT"
find "$OUT" -type f | sed "s|$OUT|.|" | sort
