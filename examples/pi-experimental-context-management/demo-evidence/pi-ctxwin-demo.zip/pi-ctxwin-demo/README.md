# pi context-window demo sandbox — published snapshot

Evidence for the agent-driven context window in
`examples/pi-experimental-context-management`, captured on 2026-09-11 from real
runs against a live OpenViking server and Volcengine's Doubao 2.1 Pro
(`doubao-seed-2-1-pro-260628`) on Ark, with `reasoning_effort: high`.

Start with `demo-long/INDEX.md` (a task larger than one context window, the agent
resets three times on its own) or `demo/INDEX.md` (the short scripted gate).
`REDACTIONS.md` lists what changed before publishing — in particular `env.sh` is
not here, so `run.sh` needs an `env.sh` of your own first (`env.sh.example`
shows its shape).

Self-contained playground for `examples/pi-experimental-context-management`.
Everything lives here: secrets, a private pi agent dir, a throwaway project, the
session files and the debug log. `~/.pi` is never touched, and the `openviking`
extension installed there is not loaded (`-ne` plus a private agent dir).

    env.sh.example  template for the secrets file (env.sh itself is not published)
    run.sh        launcher: re-syncs the extension from the repo, then runs pi
    agent/        private pi agent dir (models.json, settings.json)
    ext/          generated copy of the extension + demo config.json (do not edit)
    proj/         throwaway project the agent works in
    sessions/     pi session JSONL files
    out/ov-pi.log extension debug log

## Run

    ./.tmp/pi-ctxwin/run.sh                        # interactive TUI
    ./.tmp/pi-ctxwin/run.sh --mode text -p "..."   # one shot
    ./.tmp/pi-ctxwin/run.sh --mode text -p -c "..."  # continue last session

`run.sh` re-copies the extension from the repo on every launch, so code changes
take effect immediately. Demo settings (64k declared context window,
softPercent 55 / hardPercent 75, statusEveryTurn) live in `run.sh`, not in the
repo's `config.json`.

## Watch what happens

    tail -f .tmp/pi-ctxwin/out/ov-pi.log                  # resets, commits, sync
    grep '"stage":"window"' .tmp/pi-ctxwin/out/ov-pi.log  # window lifecycle only

Inside pi: `/viking window` prints the current window, archive and token state.

## Reset the sandbox

    rm -rf .tmp/pi-ctxwin/sessions/* .tmp/pi-ctxwin/out/*
    git -C . checkout -- /dev/null  # proj/ is scratch; re-seed by hand if needed
