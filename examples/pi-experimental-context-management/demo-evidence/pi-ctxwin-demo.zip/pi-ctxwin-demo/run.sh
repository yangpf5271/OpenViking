#!/usr/bin/env bash
# Interactive demo of the agent-driven context-window extension.
#
#   ./.tmp/pi-ctxwin/run.sh                 # interactive TUI
#   ./.tmp/pi-ctxwin/run.sh -p "one shot"   # single prompt, prints and exits
#   ./.tmp/pi-ctxwin/run.sh -c              # continue the last session
#
# Everything lives under .tmp/pi-ctxwin: its own pi agent dir, its own copy of
# the extension, its own sessions and debug log. Your ~/.pi is not touched and
# the openviking extension installed there is not loaded.
set -euo pipefail
D="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="$(cd "$D/../.." && pwd)"
SRC="$REPO/examples/pi-experimental-context-management"
source "$D/env.sh"

PI_BIN="${PI_BIN:-$(command -v pi)}"
[ -x "$PI_BIN" ] || { echo "pi not found on PATH; set PI_BIN" >&2; exit 2; }

# Always run the current repo code: re-sync sources, keep the demo config.
rsync -a --delete \
  --exclude tests --exclude node_modules --exclude config.json --exclude .git \
  "$SRC/" "$D/ext/"
cat > "$D/ext/config.json" <<'JSON'
{
  "enabled": true,
  "syncTurns": true,
  "logLevel": "info",
  "captureToolResults": true,
  "contextWindow": {
    "resetDeadlineMs": 120000,
    "archivePollMs": 3000,
    "softPercent": 55,
    "hardPercent": 75,
    "statusEveryTurn": true,
    "idleGapMinutes": 30
  }
}
JSON

# models.json / settings.json are generated from env.sh, so changing the model,
# the relay or the thinking level there is enough. Only apiKey may stay an env
# reference: pi expands $VARS in apiKey, not in baseUrl or the model id.
: "${PI_CTXWIN_REASONING:=high}"        # off | minimal | low | medium | high | xhigh
: "${PI_CTXWIN_CONTEXT_WINDOW:=64000}"  # what pi is told the context window is
if [ "$PI_CTXWIN_REASONING" = "off" ]; then
  REASONING_JSON='"reasoning": false'
  THINKING_JSON=""
else
  # A custom relay is not recognised by pi-ai's URL-based auto-detection, so
  # reasoning_effort has to be enabled explicitly.
  REASONING_JSON='"reasoning": true,
          "compat": { "supportsReasoningEffort": true, "thinkingFormat": "openai" }'
  THINKING_JSON="\"defaultThinkingLevel\": \"$PI_CTXWIN_REASONING\","
fi
cat > "$D/agent/models.json" <<JSON
{
  "providers": {
    "ctxwin-relay": {
      "name": "Volcengine Ark (context-window demo)",
      "baseUrl": "$PI_CTXWIN_LLM_BASE",
      "api": "openai-completions",
      "apiKey": "\$PI_CTXWIN_LLM_KEY",
      "authHeader": true,
      "models": [
        {
          "id": "$PI_CTXWIN_LLM_MODEL",
          "name": "$PI_CTXWIN_LLM_MODEL (window $PI_CTXWIN_CONTEXT_WINDOW, thinking $PI_CTXWIN_REASONING)",
          $REASONING_JSON,
          "input": ["text"],
          "cost": { "input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0 },
          "contextWindow": $PI_CTXWIN_CONTEXT_WINDOW,
          "maxTokens": 8192
        }
      ]
    }
  }
}
JSON
cat > "$D/agent/settings.json" <<JSON
{
  "defaultProvider": "ctxwin-relay",
  "defaultModel": "$PI_CTXWIN_LLM_MODEL",
  $THINKING_JSON
  "defaultProjectTrust": "always",
  "compaction": { "enabled": true, "reserveTokens": 8192, "keepRecentTokens": 12000 }
}
JSON

export PI_CODING_AGENT_DIR="$D/agent"
export OPENVIKING_DEBUG_LOG="$D/out/ov-pi.log"
cd "$D/proj"
exec "$PI_BIN" -ne -e "$D/ext/index.ts" --offline --session-dir "$D/sessions" "$@"
