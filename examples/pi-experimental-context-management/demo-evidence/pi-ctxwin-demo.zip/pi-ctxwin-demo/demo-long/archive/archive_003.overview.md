---
directory: viking://user/default/sessions/pi-01a08ee0-bf4b-7855-ad09-2af85dfeea53/history/archive_003/
generated_by:
  component: Session
  trigger: archive_summary
---

# Working Memory

## Session Title
Source inventory of 22 src/ files for OpenViking pi extension

## Current State
All 22 src/ files have been inventoried (22/22 checkboxes ticked in TASK.md, 22 numbered entries in INVENTORY.md). The session just completed a context window reset (w3 → w4) after finishing the inventory and answering a follow-up question about file 1. No further work is pending; awaiting the user's next request.

## Task & Goals
Primary task (COMPLETED): Execute the source inventory defined in TASK.md — work through all 22 files under src/ in alphabetical order. For each file: read its contents, append one entry to INVENTORY.md containing the file name, its responsibility, main exports, and any risky patterns, then tick the file off in TASK.md. The inventory supports future code navigation, risk assessment, and onboarding for the OpenViking pi extension codebase.

Verification step (COMPLETED): Confirmed 22/22 checkboxes ticked in TASK.md and 22 numbered entries in INVENTORY.md (## 1 through ## 22).

## Key Facts & Decisions
**Inventory scope & artifacts**
- 22 files under src/ (~411 KB total), processed in strict alphabetical order as listed in TASK.md.
- Output artifacts: INVENTORY.md (created fresh at session start, appended per file, 489 lines, 22 entries) and TASK.md (22/22 checkboxes ticked).
- Processing pattern: read tool → edit INVENTORY.md (append entry) → edit TASK.md (tick checkbox) → next file.
- INVENTORY entry schema per file: file name, responsibility description, main exports list, risk notes.
- Working directory: `/private/var/folders/lw/0ggrwjd96s7_1pf3ymlylcv00000gq/T/ov-pi-window-long-N3y1wC/proj/`

**Completed files (22/22)**
1. `src/capture-adapter.mjs` — extracts capture payloads from a conversation branch for archival; normalizes roles, handles tool results, applies faithful capture policy.
2. `src/capture-adapter.test.mjs` — test suite for extractBranchCapturePayloads covering role normalization, watermark reset, faithful capture rules, tool result handling, truncation, deduplication.
3. `src/client-archives.test.mjs` — test suite for OVClient archive-related methods.
4. `src/client.ts` — full OpenViking HTTP client (OVClient class) covering sessions, archives, search, content, filesystem, resources, URI space resolution; failure-tolerant archive methods return null/[] instead of throwing.
5. `src/config.test.mjs` — test suite for loadConfig covering defaults, env overrides, CLI config precedence, contextWindow merging/clamping, debug log paths, peer id resolution.
6. `src/config.ts` — configuration loader with defaults, config.json merge, env var overrides, value clamping, credential resolution, peer id derivation.
7. `src/context-window-adapter.test.mjs` — test suite for the pi adapter of the context window manager.
8. `src/context-window-core.mjs` — 2031-line pure harness-agnostic state machine for agent-managed context windows; virtual cut semantics, reset pipeline, header building, status lines, reminders, pi compaction fallback, persistence.
9. `src/context-window-core.test.mjs` — 2167-line comprehensive test suite for ContextWindowCore and all exported pure helpers.
10. `src/context-window.ts` — adapter binding pure ContextWindowCore to pi, OVClient, and SyncManager; exports createContextWindowManager and readPiReserveTokens.
11. `src/index-load.test.mjs` — 969-line end-to-end smoke test loading index.ts through pi's jiti loader.
12. `src/index.ts` — main extension entry point (~25KB); default async function initializes all modules, registers 9 tools + "viking" command + 9 event handlers, embeds CONTEXT_WINDOW_GUIDANCE system prompt.
13. `src/pi-settings.mjs` — reads pi's `compaction.reserveTokens` (default 16384) from project/global settings.json for reminder clamping.
14. `src/recall-deferred.test.mjs` — tests for queued recall lifecycle and session id dedup.
15. `src/recall.ts` — RecallManager class: queueSearch → searchPending → injectRecall; idempotency via `<openviking-context` guard.
16. `src/sync-barrier.test.mjs` — 14 tests covering batch drain, retries, watermark, budget caps, barrier semantics.
17. `src/sync.ts` — SyncManager: session id derivation, watermark tracking, flushBarrier, batch send (BATCH_LIMIT=100), commit, droppedForever counter.
18. `src/text-budget.mjs` — pure text/token utilities: estimateTokens, truncateToTokens, flattenContent, fingerprintMessage, countUserTurns, estimatePayloadTokens.
19. `src/text-budget.test.mjs` — tests for token estimation, truncation, user-turn detection, payload token counting.
20. `src/tools.ts` — registers all 9 tools (6 viking_* + new_context/history/get_context_remaining) with full handlers; ~31KB.
21. `src/uri-guard-adapter.mjs` — blocks non-Viking tools (read/grep/find/ls/bash) from receiving viking:// URIs; maps to correct viking_* tool suggestions.
22. `src/uri-guard.test.mjs` — 3 tests for URI guard block/allow decisions.

**Architectural decisions & invariants**
- Faithful capture is fixed on in this fork (no captureMode toggle); the archive is the only way back to a closed window.
- Tool result capture is enabled by default; the `history` tool promises the archive is readable, so tool output must reach OpenViking.
- Context window reset is fail-closed: any refusal means nothing is cut, no history is lost.
- Archive methods in OVClient distinguish "empty history" (returns []) from "unreadable server" (returns null) — the two must never be conflated.
- Two-phase startup: `session_start` fires-and-forgets `start()`; `before_agent_start` awaits the same memoized `startPromise`. Offline init (session id, window restore, tool registration) runs even when OV is down so `pi -c` doesn't replay archived windows.
- Peer extension coexistence: `peerOwnsToolSurface()` inspects `pi.getAllTools()` and compares `sourceInfo.path` with `ownDir`; re-run on every event boundary because the peer registers tools asynchronously after a health check. Stand-down is clean only before any irreversible work.
- `index.ts` registers 9 tools total: 6 viking_* tools (search, read, browse, remember, forget, add_resource) + 3 context window tools (new_context, history, get_context_remaining), plus the "viking" command and 9 event handlers.
- `new_context` has `executionMode: "sequential"` to prevent pi from parallelizing a reset with other tool calls.
- The fork ships no takeover module (takeover.ts, lib/takeover-core.mjs, shared/recall-ledger.mjs all absent) — intentional difference from upstream.
- `readPiReserveTokens` reads pi's compaction reserve from .pi/settings.json (project over global), used to clamp reminder thresholds below pi's auto-compaction line.
- `sync.ts` flushBarrier gates new_context; drain is bounded by budgetMs (default 60s via OPENVIKING_PENDING_DRAIN_BUDGET_MS) and OPENVIKING_PENDING_DRAIN_MAX_BATCHES. Non-retryable 4xx failures are dropped but advance watermark (tracked via `droppedForever`). No auto-commit on token thresholds (`commitIfNeeded` intentionally removed).
- `recall.ts` injectRecall mutates messages in place; idempotency guard checks for `<openviking-context` substring.

**Dependency patterns**
- Mixed import strategy across test files: some import from ../lib/*.mjs (compiled output), others from ../*.ts (TypeScript source).
- Multiple files import from ../shared/ (outside src/): capture-utils.mjs, credentials.mjs, workspace-peer.mjs, pending-queue.mjs, debug-log.mjs, recall-core.mjs, session-model.mjs, batch-send.mjs, profile-inject.mjs, uri-guard.mjs.
- Context window adapter imports ContextWindowCore from compiled ./lib/context-window-core.mjs (not source), and pi-settings from ./lib/pi-settings.mjs.
- `index-load.test.mjs` uses jiti loader (finds pi's bundled jiti at multiple candidate paths) and skips entirely if jiti is not found; spins up a real fake HTTP server with node:http createServer for end-to-end tests.

## Files & Context
- `/proj/TASK.md` — master task list with 22 checkboxes, all 22 ticked; defines the inventory order and requirements.
- `/proj/INVENTORY.md` — completed inventory document, 489 lines, 22 entries (## 1 through ## 22); appended to after each file read.
- `/proj/src/` — directory containing all 22 source files that were inventoried.
- `/proj/src/capture-adapter.mjs` — main export: extractBranchCapturePayloads; depends on ../shared/capture-utils.mjs and ./text-budget.mjs.
- `/proj/src/capture-adapter.test.mjs` — imports from ../lib/capture-adapter.mjs; uses node:test and node:assert/strict.
- `/proj/src/client-archives.test.mjs` — imports OVClient, archiveIdFromUri, archiveUriToRoot from ../client.ts; stubs global fetch.
- `/proj/src/client.ts` — OVClient class plus type exports and standalone helper functions; standalone exports: archiveUriToRoot, archiveIdFromUri.
- `/proj/src/config.test.mjs` — imports loadConfig, loadConfigFromModuleUrl from ../config.ts; uses temp directories and env var manipulation.
- `/proj/src/config.ts` — exports: EXTENSION_VERSION, OVContextWindowConfig interface, OVConfig interface, loadConfigFromModuleUrl, loadConfig; depends on ./shared/credentials.mjs and ./shared/workspace-peer.mjs.
- `/proj/src/context-window-adapter.test.mjs` — imports createContextWindowManager, readPiReserveTokens from ../context-window.ts; imports from ../lib/pi-settings.mjs and ../shared/pending-queue.mjs.
- `/proj/src/context-window-core.mjs` — 2031 lines; key exports: WINDOW_ENTRY_TYPE, WINDOW_HEADER_OPEN, STATUS_CUSTOM_TYPE, REMINDER_CUSTOM_TYPE, HANDOFF_MARKER, STATUS_MARKER, REMINDER_MARKER, COMPACTION_SENTINEL, windowConfig, computeCutRange, applyWindowCut, buildHandoffMessage, buildWindowHeader, formatTokens, formatDuration, effectiveThresholds, buildStatusLine, reminderText, lastUserTimestamps, lastUserTextFromBranch, messagesFromBranch, siblingToolNamesFromBranch, messageTokens, ContextWindowCore class; depends on ./text-budget.mjs.
- `/proj/src/context-window-core.test.mjs` — 2167 lines; imports from ../lib/context-window-core.mjs and ../lib/text-budget.mjs; uses node:test and node:assert/strict.
- `/proj/src/context-window.ts` — exports: createContextWindowManager, readPiReserveTokens; imports ContextWindowCore from ./lib/context-window-core.mjs, DEFAULT_RESERVE_TOKENS/readReserveTokens from ./lib/pi-settings.mjs, listPending from ./shared/pending-queue.mjs.
- `/proj/src/index-load.test.mjs` — 969 lines; loads index.ts via jiti from pi's installation; uses node:test, node:http createServer, temp directories, env var manipulation.
- `/proj/src/index.ts` — default async function export only; imports from ./shared/debug-log.mjs, ./config.js, ./client.js, ./recall.js, ./sync.js, ./shared/profile-inject.mjs, ./lib/uri-guard-adapter.mjs, ./tools.js, ./context-window.js, ./lib/context-window-core.mjs.
- `/proj/src/pi-settings.mjs` — exports: DEFAULT_RESERVE_TOKENS (16384), reserveTokensFromSettings, pickReserveTokens, settingsPaths, readReserveTokens; depends on node:fs and node:path.
- `/proj/src/recall-deferred.test.mjs` — imports RecallManager from ../recall.ts; uses node:test and node:assert/strict.
- `/proj/src/recall.ts` — exports: RecallCache interface, RecallManager class; imports from ./shared/recall-core.mjs.
- `/proj/src/sync-barrier.test.mjs` — imports SyncManager from ../sync.ts; imports enqueue, listPending from ../shared/pending-queue.mjs; uses temp directories via OPENVIKING_PENDING_DIR.
- `/proj/src/sync.ts` — exports: AddPayloadResult interface, SyncBranchResult interface, SyncManager class; imports from ./shared/debug-log.mjs, ./shared/session-model.mjs, ./shared/pending-queue.mjs, ./shared/batch-send.mjs, ./lib/capture-adapter.mjs, ./lib/text-budget.mjs.
- `/proj/src/text-budget.mjs` — exports: CONTEXT_BLOCK_MARKER, flattenContent, fingerprintMessage, isUserTurnStart, countUserTurns, estimateTokens, truncateToTokens, estimatePayloadTokens; pure functions, no external deps.
- `/proj/src/text-budget.test.mjs` — imports from ../lib/text-budget.mjs; uses node:test and node:assert/strict.
- `/proj/src/tools.ts` — exports: registerTools, registerContextWindowTools, ContextWindowToolOptions interface; imports from typebox, @earendil-works/pi-ai, ./client.js, ./config.js, ./sync.js, ./lib/context-window-core.mjs, ./context-window.js.
- `/proj/src/uri-guard-adapter.mjs` — exports: guardVikingUriToolCall; imports from ../shared/uri-guard.mjs.
- `/proj/src/uri-guard.test.mjs` — imports guardVikingUriToolCall from ../lib/uri-guard-adapter.mjs; uses node:test and node:assert/strict.

## Errors & Corrections
- INVENTORY.md did not exist at session start (ENOENT error on first read); resolved by creating the file before writing the first entry.
- Initial read of TASK.md path was attempted at root level before confirming directory structure; resolved by running ls to confirm proj/ layout with src/ subdirectory and TASK.md at proj root.
- context-window-core.mjs was too large for a single read (truncated at 301-line offset, then 701, then 1101, then 1501); resolved by reading in chunks with offset parameter until end of file was reached and verified via wc -l (2031 lines total).
- The context-window-core.mjs entry (file 8) was lost during the w1→w2 context reset (TASK.md showed it unchecked, INVENTORY.md only had 7 entries); resolved by reconstructing and writing the entry at the start of w2 before proceeding to file 9.
- context-window-core.test.mjs was too large for a single read (2167 lines); resolved by reading in chunks at offsets 501, 1001, 1501, 2001 until complete.
- index-load.test.mjs was too large for a single read (969 lines); resolved by reading in chunks at offset 501.

## Open Issues
- [resolved] All 22 src/ files have been inventoried and ticked off in TASK.md; INVENTORY.md contains all 22 entries.
- [resolved] index.ts (~25KB) and tools.ts (~31KB) were large files requiring multiple offset reads — both completed successfully.
- [open] Several files import from ../shared/ modules outside src/ — their full dependency picture will not be complete until those shared files are examined (though the current task only covers src/).
- [open] Mixed .mjs/.ts import patterns across test suites may indicate a build step producing lib/ output — this has not been confirmed yet.
- [open] The fork ships no takeover module (takeover.ts, lib/takeover-core.mjs, shared/recall-ledger.mjs all absent) — verified by index-load.test.mjs; this is an intentional difference from upstream.
- [silently dropped, restored] 11 files remain to be inventoried (files 12–22): index.ts, pi-settings.mjs, recall-deferred.test.mjs, recall.ts, sync-barrier.test.mjs, sync.ts, text-budget.mjs, text-budget.test.mjs, tools.ts, uri-guard-adapter.mjs, uri-guard.test.mjs.
- [silently dropped, restored] index.ts at ~25KB and tools.ts at ~31KB are large files that will likely require multiple offset reads to fully capture.
- [silently dropped, restored] Several remaining files import from ../shared/ modules outside src/ — their full dependency picture will not be complete until those shared files are examined (though the current task only covers src/).
- [silently dropped, restored] No verification step has been run to confirm all 22 checkboxes are ticked and all 22 entries are present in INVENTORY.md — this should happen after the last file is processed.

