# Source inventory task

There are 22 files under src/ (~411 KB).
Work through them in alphabetical order:

- [x] src/capture-adapter.mjs
- [x] src/capture-adapter.test.mjs
- [x] src/client-archives.test.mjs
- [x] src/client.ts
- [x] src/config.test.mjs
- [x] src/config.ts
- [x] src/context-window-adapter.test.mjs
- [x] src/context-window-core.mjs
- [x] src/context-window-core.test.mjs
- [x] src/context-window.ts
- [x] src/index-load.test.mjs
- [x] src/index.ts
- [x] src/pi-settings.mjs
- [x] src/recall-deferred.test.mjs
- [x] src/recall.ts
- [x] src/sync-barrier.test.mjs
- [x] src/sync.ts
- [x] src/text-budget.mjs
- [x] src/text-budget.test.mjs
- [x] src/tools.ts
- [x] src/uri-guard-adapter.mjs
- [x] src/uri-guard.test.mjs
